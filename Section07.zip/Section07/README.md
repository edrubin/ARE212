# Section 7 files

- PDF version of online notes.
- R script that follows section notes.
- RMarkdown file that created the online notes.
