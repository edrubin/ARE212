# Section 8 files

- PDF version of online notes.
- R script that follows section notes.
