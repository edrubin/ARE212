# Section 12 files

- Zipped folder for Chicago police beat shapefiles
- `.rds` file of Chicago crime 2010–2016
- PDF version of online notes.
- R script that follows section notes.
