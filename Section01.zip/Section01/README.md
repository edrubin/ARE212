# Section 1 files

- CSV and DTA versions of the car dataset
- PDF version of the online notes
- R script following the notes
