# Section 4 files

- PDF version of online notes.
- CSV form of automobile data (auto.csv).
- Rscript of code from section.
