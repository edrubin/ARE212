# Section 5 files

- PDF version of online notes.
- CSV form of automobile data (auto.csv).
