# Section 9 files

- PDF version of online notes.
- CSV form of automobile data (auto.csv).
- R script that follows section notes.
