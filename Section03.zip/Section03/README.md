# Section 3 files

- PDF version of the online notes
- R script following the notes
- auto.dta (Stata) data file
