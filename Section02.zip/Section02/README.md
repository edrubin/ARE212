# Section 2 files

- PDF version of the online notes
- R script following the notes
